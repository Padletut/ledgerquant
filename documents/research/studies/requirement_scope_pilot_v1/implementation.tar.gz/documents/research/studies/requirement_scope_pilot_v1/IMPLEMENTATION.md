# Requirement-scope pilot: preparation implementation

**Date:** 10 October 2026  
**Architecture:** 2.16 · **Implementation plan:** 1.9  
**State:** Preparation stopped as `INSUFFICIENT_FAMILY_DIVERSITY`; explicit `DO_NOT_START`. All 24 supplied decision rows and the follow-up clarification are retained with declared reviewer type `AI_ASSISTANT`. See [review status](REVIEW_STATUS.md).

Start with the [human review guide](review/README.md). It links the original
24 synthetic proposals, their context, binding source requirements and blank
review forms. The user can submit judgements in chat. No knowledge of hashes or
JSON is needed to review a case.

## What was built

`src/ledgerquant/research/scope_pilot/` owns a complete **offline preparation and
scoring workflow**. It does not dispatch model calls, open PostgreSQL, read
credentials or grant a process-assessment permission.

| Module | Implemented responsibility |
| --- | --- |
| `contracts.py` | Strict worker-visible case packet; one class-constrained finding and escalation route; separate human references, recorded results and semantic grades. |
| `inputs.py` | Design-integrity checks, paired alternating schedule, exact isolated request compilation, byte limits and conservative reservation calculation. |
| `artifacts.py` | Implementation verification and immutable export of explicit human references with reviewed family membership. |
| `review.py` | Readable case exports; blank review forms; arm-blind output grading and hash-bound import of manual grades. |
| `scoring.py` | All 48 scheduled rows; symmetric invalid-reference exclusions; technical failures retained separately; frozen descriptive Track A/Track B rules. |
| `__main__.py` | Offline commands connecting these operations without a provider-execution command. |

The answer uses the existing `Finding` shape with the code constrained to
`REQUIREMENT_SCOPE_CONFUSION`. `ASSESSABLE` requires reason `NONE`; escalation
requires a registered reason. An unresolved finding must escalate. A proposed
answer is never a `REVIEWED` process assessment. A valid reference records an
explicit reviewer, time, exact packet identity, field citations and rationale
acceptance criterion. The local operator remains trusted to record actual human
decisions; this is not authenticated reviewer delegation.

The same frozen history, prompt, schema, model and current packet enter both
arms. The treatment adds only the previously selected `model_input` lesson.
Probe requests are identical. Inputs contain no family/stratum assignment,
reference decision, competing answer or grading record. Schema rejection tests
cover extra fields; semantic injection remains untrusted text, not a new tool.

## Freeze and authoring sequence

1. Commit `f08208e` preserved the previously frozen pilot design.
2. Fourteen pilot tests were developed using separate development fixtures.
   All 90 repository unit tests passed before candidate authoring.
3. [Implementation freeze](../../../../configs/research/studies/requirement_scope_pilot_v1/implementation.freeze.json)
   bound 54 implementation/dependency/test files and the prompt/schema hashes at
   `2026-10-10T01:18:26.535075+00:00`.
4. Only then were 24 candidate packets authored, organized into eight proposed
   structural groupings. The [candidate manifest](../../../../configs/research/studies/requirement_scope_pilot_v1/candidates.freeze.json)
   binds the ordered inventory, implementation identity and operator authoring
   record. No model was invoked on these candidates.
5. Request serialization and review export were performed without tuning the
   frozen implementation or evaluating model performance on the new cases.

The original `study.json`, `history.json`, `method_feedback.json`, model profile,
`design.freeze.json` and [protocol](PROTOCOL.md) remain unchanged. The historical
design fields saying `NOT_AUTHORED` or `REQUIRES_HARNESS_IMPLEMENTATION` describe
that earlier freeze. [Readiness](../../../../configs/research/studies/requirement_scope_pilot_v1/readiness.json)
is the current, derived checklist; it grants no authority.

Author targets and proposed family ancestry are retained separately under
`data/research_control/operator/requirement_scope_pilot_v1/authoring_v1/`.
They are not human reference labels and are not in the review pages or
worker-readable research database. Preserve that directory in operator backups;
Git contains its content identity, not its suggested answers. The operator
supplies `FAMILY_REVIEW.md` only after individual case judgements are recorded.

All candidate packets use v2. This inventory cannot establish v3 coverage.
Shared scope rules and development ancestry are declared. The eight proposed
groupings were assessed in the follow-up: G1/G6 and G2/G8 merge, G3/G7 separation is unresolved, and G4/G5 are only provisionally distinct. Escalation membership does not establish eight coherent triples. Preparation is stopped under the existing gate.
Fewer than eight supported groups yields `INSUFFICIENT_FAMILY_DIVERSITY`. The
authoring record explicitly identifies potentially related groups. Neither an
opaque ID nor a changed source name establishes independence.

## Offline preflight

From the repository root:

```bash
PYTHONPATH=src .venv/bin/python -m ledgerquant.research.scope_pilot preflight \
  --cases configs/research/studies/requirement_scope_pilot_v1/cases.json
```

This verifies the design and implementation freezes, then serializes the 48
assessments with one probe and one answer request each. It prints request hashes
and reservations; it makes **zero provider calls**.

Measured preparation results:

| Check | Result |
| --- | --- |
| Candidate packets | 24 unique opaque IDs, schema-valid synthetic v2 proposals |
| Largest canonical packet | 2,144 bytes; frozen maximum 4,096 |
| Planned assessments / requests | 48 / 96 |
| Conservative reservation for these serialized requests | USD 1.850928 under the historical profile tariff |
| Planned study ceiling | USD 3; allocation remains zero |
| Actual provider spend for this preparation | USD 0 |
| Pilot unit tests / all unit tests | 14 / 90 passed |

The request reservation is neither an invoice nor a newly allocated allowance.
Official current prices and all existing campaign reservations must be checked
before execution within the original aggregate USD 50 authorization.

## Human references and later grading

First review each original packet without the author's intended answer. Record
status, route/reason, component, severity, supporting paths, a short explanation
and what a correct explanation must get right. Flag ambiguous or invalid cases.
Then review family ancestry. The operator can transcribe chat decisions into
`Reference` records, preserving the actual reviewer and review time, and use
`freeze-references` to publish an immutable reference set. Incomplete references
or unsupported family separation fail that export. It never authorizes inference.

The later `blind-outputs` command prepares grading packets containing the current
case, its reviewed reference and one answer. Arm labels, invocation IDs and result
hashes are held in a separate operator mapping. Wording may still reveal the
treatment; metadata blinding is not perfect semantic blinding. `import-grades`
verifies that the source case/reference/answer text was not changed and binds
the explicit human grade back to the original result. Blank grades stay unresolved.

`score` retains the entire schedule, including missing answers and technical
failures. Invalid references remove both arms of the same case from semantic
denominators. Exact correctness requires status, attribution, citations, routing
and rationale. Path existence alone cannot establish semantic citation support.
Unresolved grading, failed/missing output, invalid reference, unsupported family
separation or early termination makes the pilot inconclusive. A promising label
grants no automatic permission and makes no economic or generalization claim.

## Remaining execution boundary

The following have **not** been implemented or verified by this offline build:

- Independent human reference review and supported family diversity. The follow-up accepts rationale criteria with the case 15 clarification but declares `AI_ASSISTANT`. The diversity gate failed; no complete reference set is frozen.
- Binding this pilot's compiled requests to the existing durable registry/runtime
  with campaign ownership, idempotent delivery, per-call reservations, full
  failed-dispatch accounting and the registered stopping rules.
- Actual worker denial of operator references through mounts, DB reads, tools,
  logs and error paths. Typed serialization checks do not prove runtime isolation.
- Live lesson/source eligibility, current provider tariffs, aggregate budget
  allocation and the final execution manifest.
- Real model performance, hosted identity behavior or treatment benefit.

There is no next execution step for this stopped allocation. Any separately authorized, linked study must declare its reference authority and revised allocation before inference. Any later execution integration must preserve or explicitly version the frozen
prompt/schema/scorer and exact request identities. Freeze its implementation and
deployment checks in the final execution manifest before dispatch. If a bound
implementation or case needs correction, preserve the current freeze, record a
linked revision and the exposure already incurred; do not silently overwrite or
tune against subsequent pilot outcomes. No production capture database or live
collector was changed by this preparation.

"""Completion-inclusive descriptive scoring; never an agent or release authority."""

from collections import Counter, defaultdict
from statistics import mean

from ..types import digest
from .contracts import Case, Grade, Reference, Result
from .inputs import ARMS, Design, reference_exists, schedule


def _unique(items, key):
    result = {}
    for item in items:
        identity = key(item)
        if identity in result:
            raise ValueError("DUPLICATE_SCORING_INPUT")
        result[identity] = item
    return result


def _row(case, arm, ref, result, grade):
    eligible = ref is not None and ref.state == "VALID"
    answer = result.answer if result else None
    graded = bool(eligible and answer and grade and grade.state == "RESOLVED"
                  and grade.reference_sha256 == digest(ref))
    dimensions = {}
    if eligible and answer:
        expected, finding = ref.expected, answer.finding
        dimensions = {
            "status": finding.status == expected.finding.status,
            "attribution": (finding.responsible_component, finding.severity) ==
                           (expected.finding.responsible_component, expected.finding.severity),
            "routing": (answer.route, answer.escalation_reason) == (expected.route, expected.escalation_reason),
            "citations": all(reference_exists(case, r) for r in finding.references)
                         and bool(graded and grade.citations_supported),
            "rationale": bool(graded and grade.rationale_correct),
        }
    return {"case_id": case.case_id, "arm": arm, "family_id": ref.family_id if ref else None,
            "semantic_eligible": eligible, "technical_status": result.status if result else "NOT_STARTED",
            "technical_failure_is_agent_defect": False, "graded": graded,
            "exact": int(graded and all(dimensions.values())) if eligible else None,
            "dimensions": dimensions, "exclusion": None if eligible else (ref.state if ref else "MISSING_REFERENCE")}


def score(design: Design, cases: list[Case], references: list[Reference], results: list[Result],
          grades: list[Grade], *, families_verified: bool, early_stop=False, source_or_authority_violations=0):
    if type(source_or_authority_violations) is not int or source_or_authority_violations < 0:
        raise ValueError("INVALID_VIOLATION_COUNT")
    planned = schedule(cases)
    packets = {case.case_id: case for case in cases}
    refs = _unique(references, lambda x: x.case_id)
    outputs = _unique(results, lambda x: (x.case_id, x.arm))
    markings = _unique(grades, lambda x: x.result_sha256)
    if set(refs) - set(packets) or {r.case_id for r in results} - set(packets):
        raise ValueError("UNSCHEDULED_SCORING_INPUT")
    for item in (*references, *results):
        if item.packet_sha256 != digest(packets[item.case_id]):
            raise ValueError("SCORING_PACKET_HASH_MISMATCH")
    for ref in references:
        if ref.state == "VALID" and not all(reference_exists(packets[ref.case_id], r) for r in ref.expected.finding.references):
            raise ValueError("INVALID_REFERENCE_CITATION")
    rows = []
    for case, arm in planned:
        result = outputs.get((case.case_id, arm))
        grade = markings.get(digest(result)) if result else None
        rows.append(_row(case, arm, refs.get(case.case_id), result, grade))
    family_rows = defaultdict(lambda: defaultdict(list))
    for row in rows:
        if row["semantic_eligible"]:
            family_rows[row["family_id"]][row["arm"]].append(row["exact"])
    family_scores = {key: {arm: mean(group[arm]) for arm in ARMS} for key, group in family_rows.items()}
    for scores in family_scores.values():
        scores["delta"] = scores[ARMS[1]] - scores[ARMS[0]]
    delta = mean(s["delta"] for s in family_scores.values()) if family_scores else None
    counts = Counter()
    for row in rows:
        if row["arm"] != ARMS[1] or not row["semantic_eligible"]:
            continue
        ref = refs[row["case_id"]]
        result = outputs.get((row["case_id"], ARMS[1]))
        answer = result.answer if result else None
        status = answer.finding.status if answer else None
        assessable = bool(answer and answer.route == "ASSESSABLE")
        if ref.stratum != "MANDATORY_ESCALATION":
            counts["in_class_denominator"] += 1
            counts["correct_in_class"] += row["exact"]
            counts["assessable_coverage"] += assessable
            counts["abstention"] += bool(answer and not assessable)
        if ref.stratum == "VALID_NEAR_MISS":
            counts["near_miss_denominator"] += 1
            counts["false_accusations"] += status == "SUPPORTED"
        elif ref.stratum == "SUPPORTED_SCOPE_DEFECT":
            counts["defect_denominator"] += 1
            counts["missed_defects"] += not (status == "SUPPORTED" and assessable)
        else:
            counts["mandatory_denominator"] += 1
            counts["missed_escalations"] += not row["dimensions"].get("routing", False)
        counts["assessable_total"] += assessable
        counts["errors_among_assessable"] += bool(assessable and not row["exact"])
        if answer:
            counts["wrong_component_or_severity"] += not row["dimensions"]["attribution"]
            # Unknown semantic grades are not fabricated errors. Overall result remains inconclusive.
            counts["invalid_or_unsupported_citation"] += (not all(reference_exists(packets[row["case_id"]], r)
                for r in answer.finding.references) or bool(row["graded"] and not row["dimensions"]["citations"]))
            counts["incorrect_scope_explanation"] += bool(row["graded"] and not row["dimensions"]["rationale"])
    metrics = ("false_accusations", "missed_defects", "missed_escalations", "correct_in_class", "abstention",
               "assessable_coverage", "errors_among_assessable", "wrong_component_or_severity",
               "invalid_or_unsupported_citation", "incorrect_scope_explanation", "in_class_denominator",
               "near_miss_denominator", "defect_denominator", "mandatory_denominator", "assessable_total")
    track_b = {name: counts[name] for name in metrics}
    family_strata = defaultdict(Counter)
    for ref in references:
        if ref.state == "VALID":
            family_strata[ref.family_id][ref.stratum] += 1
    required_strata = Counter(design.study["inventory"]["strata_per_family"])
    valid_families = len(family_strata) == 8 and all(s == required_strata for s in family_strata.values())
    complete = sum(row["graded"] for row in rows)
    inconclusive = (early_stop or source_or_authority_violations > 0 or not families_verified or not valid_families or complete != 48
                    or any(not row["semantic_eligible"] for row in rows))
    gates = design.study["pilot_decision"]
    promising = (delta is not None and delta >= gates["minimum_track_a_delta"]
        and counts["correct_in_class"] >= gates["minimum_treatment_correct_in_class"]
        and counts["false_accusations"] <= gates["maximum_treatment_false_accusations"]
        and counts["missed_defects"] <= gates["maximum_treatment_missed_defects"]
        and counts["missed_escalations"] <= gates["maximum_treatment_missed_escalations"]
        and source_or_authority_violations <= gates["maximum_source_or_authority_violations"])
    return {"study_sha256": digest(design.study), "scheduled": 48, "complete_graded": complete,
            "decision": gates["incomplete_label"] if inconclusive else gates["promising_label"] if promising else gates["not_promising_label"],
            "track_a": {"family_scores": family_scores, "delta": delta}, "track_b": track_b, "rows": rows,
            "source_or_authority_violations": source_or_authority_violations,
            "unmatched_grades": sorted(set(markings) - {digest(result) for result in results}),
            "automatic_permissions": [], "inference": "DESCRIPTIVE_PAIRED_AUTHORED_FAMILIES_ONLY"}

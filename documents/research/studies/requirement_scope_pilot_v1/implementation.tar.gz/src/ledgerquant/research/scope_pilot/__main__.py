"""Offline preparation commands. No provider credential, DB connection or dispatch."""

import argparse
import json
from pathlib import Path

from ..immutable import publish_directory
from .artifacts import freeze_references, read_cases, verify_implementation
from .contracts import Grade, Reference, Result
from .inputs import compile_inventory, load_design
from .review import blind_outputs, export_review, import_grades
from .scoring import score


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    sub = parser.add_subparsers(dest="command", required=True)
    grading = sub.add_parser("import-grades")
    grading.add_argument("--pages", type=Path, required=True)
    grading.add_argument("--mapping", type=Path, required=True)
    grading.add_argument("--reviewer", required=True)
    grading.add_argument("--output", type=Path, required=True)
    for name in ("preflight", "review", "freeze-references", "blind-outputs", "score"):
        command = sub.add_parser(name)
        command.add_argument("--cases", type=Path, required=True)
        if name != "preflight":
            command.add_argument("--output", type=Path, required=True)
        if name in {"freeze-references", "blind-outputs", "score"}:
            command.add_argument("--references", type=Path, required=True)
        if name == "freeze-references":
            command.add_argument("--family-review", type=Path, required=True)
        if name in {"blind-outputs", "score"}:
            command.add_argument("--results", type=Path, required=True)
        if name == "blind-outputs":
            command.add_argument("--private-mapping", type=Path, required=True)
        if name == "score":
            command.add_argument("--grades", type=Path, required=True)
            command.add_argument("--early-stop", action="store_true")
            command.add_argument("--source-or-authority-violations", type=int, default=0)
    args = parser.parse_args()
    directory = args.root / "configs/research/studies/requirement_scope_pilot_v1"
    design = load_design(args.root, directory)
    verify_implementation(args.root, directory / "implementation.freeze.json")
    if args.command == "import-grades":
        grades = import_grades(args.pages, json.loads(args.mapping.read_text()), args.reviewer)
        publish_directory(args.output, {"grades.json": (json.dumps([g.model_dump(mode="json") for g in grades], indent=2) + "\n").encode()})
        print(json.dumps({"imported": len(grades), "resolved": sum(g.state == "RESOLVED" for g in grades)}))
        return
    cases = read_cases(args.cases)
    if args.command == "preflight":
        result = compile_inventory(design, cases)
    elif args.command == "review":
        result = export_review(design, cases, args.output)
    else:
        raw = json.loads(args.references.read_text())
        if args.command == "freeze-references":
            refs = [Reference.model_validate(item) for item in raw]
            result = {"reference_freeze_sha256": freeze_references(design, cases, refs,
                json.loads(args.family_review.read_text()), args.output)}
        else:
            refs = [Reference.model_validate(item) for item in raw["references"]]
            from ..types import digest
            if raw["study_sha256"] != digest(design.study):
                raise ValueError("REFERENCE_STUDY_MISMATCH")
            results = [Result.model_validate(item) for item in json.loads(args.results.read_text())]
            if args.command == "blind-outputs":
                blind_outputs(cases, refs, results, args.output, args.private_mapping)
                result = {"status": "BLIND_REVIEW_EXPORTED"}
            else:
                grades = [Grade.model_validate(item) for item in json.loads(args.grades.read_text())]
                clusters = raw["family_review"]["clusters"]
                verified = (len(clusters) == 8 and len({c["family_id"] for c in clusters}) == 8
                            and all(c["separation_supported"] is True and c["ancestry_reason"] for c in clusters))
                result = score(design, cases, refs, results, grades, families_verified=verified,
                    early_stop=args.early_stop, source_or_authority_violations=args.source_or_authority_violations)
                publish_directory(args.output, {"score.json": (json.dumps(result, indent=2) + "\n").encode()})
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

"""Frozen, synthetic requirement-scope pilot; no assessment or release authority."""

"""Worker-visible packets and separate operator-only reference/grade contracts."""

from typing import Annotated, Literal

from pydantic import AwareDatetime, Field, model_validator

from ..grounded_proposals import ProposalV3
from ..process_assessment import Finding
from ..scoped_proposals import ProposalV2
from ..types import Record, canonical


Hash = Annotated[str, Field(pattern=r"^[a-f0-9]{64}$")]
CaseID = Annotated[str, Field(pattern=r"^c_[a-f0-9]{12}$")]
Arm = Literal["HISTORY_ONLY", "HISTORY_PLUS_REVIEWED_METHODS"]
Reason = Literal["NONE", "AMBIGUOUS_SCOPE", "OUT_OF_CLASS", "INVALID_CONTEXT", "INTEGRITY_CONFLICT",
                 "UNCERTAIN_LINEAGE_OR_EXPOSURE", "HIGH_IMPACT", "MATERIAL_DISAGREEMENT"]
Stratum = Literal["SUPPORTED_SCOPE_DEFECT", "VALID_NEAR_MISS", "MANDATORY_ESCALATION"]


class Context(Record):
    current_scope: str = Field(min_length=1, max_length=1200)
    record_notes: tuple[str, ...] = Field(max_length=8)


class Case(Record):
    case_id: CaseID
    provenance: Literal["OPERATOR_AUTHORED_SYNTHETIC"]
    task: str = Field(min_length=1, max_length=500)
    context: Context
    draft: Annotated[ProposalV2 | ProposalV3, Field(discriminator="schema_version")]

    @model_validator(mode="after")
    def bounded(self):
        if len(canonical(self).encode()) > 4096:
            raise ValueError("CASE_PACKET_TOO_LARGE")
        return self


class ScopeFinding(Finding):
    code: Literal["REQUIREMENT_SCOPE_CONFUSION"]


class Answer(Record):
    finding: ScopeFinding
    route: Literal["ASSESSABLE", "ESCALATE"]
    escalation_reason: Reason

    @model_validator(mode="after")
    def routing(self):
        if (self.route == "ASSESSABLE") != (self.escalation_reason == "NONE"):
            raise ValueError("route and escalation reason disagree")
        if self.finding.status == "UNRESOLVED" and self.route != "ESCALATE":
            raise ValueError("unresolved findings require escalation")
        return self


class Reference(Record):
    """Operator reference, never supplied to the assessed model or research DB."""
    case_id: CaseID
    packet_sha256: Hash
    family_id: str = Field(min_length=1, max_length=100)
    stratum: Stratum
    state: Literal["VALID", "INVALID", "UNRESOLVED"]
    expected: Answer
    acceptance: str = Field(min_length=1, max_length=3000)
    reviewer: str = Field(min_length=1, max_length=120)
    reviewed_at: AwareDatetime
    author_labels_seen: Literal[False]
    reason: str = Field(min_length=1, max_length=2000)

    @model_validator(mode="after")
    def reference_matches_stratum(self):
        if self.state == "VALID":
            status, route = self.expected.finding.status, self.expected.route
            if self.stratum == "SUPPORTED_SCOPE_DEFECT" and (status, route) != ("SUPPORTED", "ASSESSABLE"):
                raise ValueError("defect stratum requires an assessable supported reference")
            if self.stratum == "VALID_NEAR_MISS" and (status, route) != ("NOT_SUPPORTED", "ASSESSABLE"):
                raise ValueError("near-miss stratum requires an assessable unsupported reference")
            if self.stratum == "MANDATORY_ESCALATION" and route != "ESCALATE":
                raise ValueError("mandatory stratum requires escalation")
        return self


class Result(Record):
    case_id: CaseID
    packet_sha256: Hash
    arm: Arm
    status: Literal["COMPLETED", "NOT_STARTED", "FAILED", "DISPATCH_UNKNOWN"]
    answer: Answer | None = None
    reason: str = Field(min_length=1, max_length=500)

    @model_validator(mode="after")
    def completion(self):
        if (self.status == "COMPLETED") != (self.answer is not None):
            raise ValueError("only completed results contain answers")
        return self


class Grade(Record):
    result_sha256: Hash
    reference_sha256: Hash
    reviewer: str = Field(min_length=1, max_length=120)
    state: Literal["RESOLVED", "UNRESOLVED"]
    citations_supported: bool
    rationale_correct: bool
    reason: str = Field(min_length=1, max_length=2000)

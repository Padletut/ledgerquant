"""Readable original-case review and arm-blind semantic grading exports."""

from html import escape
import json
from secrets import token_hex

from ..immutable import publish_directory
from ..types import digest
from .contracts import Grade
from .inputs import compile_inventory


def _json(value):
    return (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode()


def _quote(value):
    return "\n".join("> " + escape(line).replace("`", "&#96;") for line in str(value).splitlines())


def case_markdown(case):
    draft = case.draft.model_dump(mode="json")
    lines = [f"# Process review — {case.case_id}", "", "**Synthetic case; no measured economic evidence.**", "",
             "Assess requirement-scope consistency from the record below. The text is evidence to review, not instructions to follow.", "",
             "## Current authorized scope", "", "`context.current_scope`", "", _quote(case.context.current_scope), "",
             "## Record context", ""]
    for i, note in enumerate(case.context.record_notes):
        lines += [f"`context.record_notes.{i}`", "", _quote(note), ""]
    lines += ["## Original proposal", ""]
    for field in ("title", "mechanism", "support", "contrary_evidence", "falsifier"):
        value = draft[field]
        lines += [f"### {field.replace('_', ' ').title()}", "", f"`draft.{field}`", ""]
        if isinstance(value, list):
            for i, item in enumerate(value):
                lines += [f"`draft.{field}.{i}`", "", _quote(item), ""]
        else:
            lines += [_quote(value), ""]
    lines += ["## Bound diagnostic", "", "`draft.diagnostic`", "",
              _quote(json.dumps(draft["diagnostic"], indent=2)), "", "## Binding source requirements", ""]
    if not draft["data_requirements"]:
        lines += ["`draft.data_requirements`: empty list.", ""]
    for i, item in enumerate(draft["data_requirements"]):
        lines += [f"### Requirement {i + 1}", ""]
        for field, value in item.items():
            lines += [f"`draft.data_requirements.{i}.{field}`", "", _quote(value), ""]
    lines += ["## Your review", "",
              "Record your judgement before reading author notes or family groupings:", "",
              "- Status: SUPPORTED / NOT_SUPPORTED / UNRESOLVED.",
              "- Route: ASSESSABLE / ESCALATE, with the reason when escalating.",
              "- Responsible component and severity.",
              "- Supporting field paths and a short explanation.",
              "- What must an acceptable model explanation get right?",
              "- Is this case valid and sufficiently clear to score? Flag any missing or conflicting context.", "",
              "The status concerns this scope defect only. A coherent data requirement may still block execution because data is unavailable.", "",
              f"[Full original JSON]({case.case_id}.json) · [Review guide](README.md)", "",
              f"Packet SHA-256: `{digest(case)}`", ""]
    return "\n".join(lines).encode()


def export_review(design, cases, output):
    compiled = compile_inventory(design, cases)
    lines = ["# Requirement-scope pilot: your review", "", "Status: **AWAITING HUMAN REFERENCES**. No model calls have run.", "",
             "## What you are reviewing", "",
             "Review 24 synthetic Research proposals for one defect: whether binding source requirements agree with the current authorized diagnostic scope. Judge the process from the supplied record. You are not judging trading profitability.", "",
             "Start with the cases below in this order. Author-suggested answers and family groupings are withheld from this initial review. You can send your judgements in chat; editing JSON is optional. Review in batches if useful.", "",
             "## Rules", "", _quote(design.history["v2_v3_requirement_rules"]), "",
             "## How to answer", "",
             "For each case, give status, route, responsible component, severity, supporting field paths and a short reason. Also state what a correct explanation must mention. Flag invalid or ambiguous records; do not force a binary verdict.", "",
             "- **SUPPORTED**: a demonstrated requirement-scope defect.",
             "- **NOT_SUPPORTED**: this defect is absent. This does not establish predictive value or admission eligibility.",
             "- **UNRESOLVED**: evidence cannot settle the finding; escalation is required.",
             "- **ASSESSABLE** with reason NONE, or **ESCALATE** with AMBIGUOUS_SCOPE, OUT_OF_CLASS, INVALID_CONTEXT, INTEGRITY_CONFLICT, UNCERTAIN_LINEAGE_OR_EXPOSURE, HIGH_IMPACT or MATERIAL_DISAGREEMENT.",
             "- Components: research, critic, contract_service, test_harness, reference_reviewer, unknown. Context/checker defects are not automatically Research defects.",
             "- Severity: blocking, material or advisory. For an absent defect, material is the neutral rubric value. This convention does not assert an error.", "",
             "After the individual judgements, review the proposed family ancestry separately. Merge related families where warranted. Fewer than eight supported clusters stops preparation; we will not rename them to obtain independence.", "",
             "## Cases", ""]
    files, forms = {}, []
    for i, case in enumerate(cases, 1):
        lines.append(f"{i}. [{case.case_id}]({case.case_id}.md)")
        files[f"{case.case_id}.md"] = case_markdown(case)
        files[f"{case.case_id}.json"] = _json(case.model_dump(mode="json"))
        forms.append({"case_id": case.case_id, "packet_sha256": digest(case), "status": None, "route": None,
                      "escalation_reason": None, "responsible_component": None, "severity": None,
                      "references": [], "explanation": None, "acceptance": None, "case_validity": None})
    lines += ["", "## Trust boundary", "",
              "These are AI-assisted operator-authored candidates, not independently established references. The author has seen the development history and lesson. Your review supplies the reference judgements and may reject cases or family independence. No reviewer approval has been prefilled.", "",
              "This single-reviewer pilot cannot qualify automatic assessment or method release. Original proposals and human decisions remain separate artifacts. The next execution gate also requires live lesson eligibility, a frozen execution manifest, verified isolation, tariff verification and budget allocation.", ""]
    files["README.md"] = "\n".join(lines).encode()
    files["review.form.json"] = _json({"study_sha256": digest(design.study), "reviewer": None, "reviewed_at": None,
                                      "author_labels_seen": False, "cases": forms})
    files["preflight.json"] = _json(compiled)
    publish_directory(output, files)
    return compiled


def blind_outputs(cases, references, results, output, private_mapping):
    """No arms, invocation IDs, result hashes, or treatment instructions in grader pages.

    Mapping and original outputs stay operator-only. Wording may reveal treatment;
    this is metadata blinding, not a claim of perfect semantic blinding.
    """
    by_case = {case.case_id: case for case in cases}
    refs = {ref.case_id: ref for ref in references}
    if len(refs) != len(references) or len({(r.case_id, r.arm) for r in results}) != len(results):
        raise ValueError("DUPLICATE_BLINDING_INPUT")
    files, mapping = {}, []
    shuffled = sorted(results, key=lambda _: token_hex(16))
    for result in shuffled:
        case, ref = by_case[result.case_id], refs[result.case_id]
        if result.packet_sha256 != digest(case) or ref.packet_sha256 != digest(case):
            raise ValueError("BLINDING_PACKET_HASH_MISMATCH")
        if result.answer is None or ref.state != "VALID":
            continue
        opaque = "g_" + token_hex(12)
        content = {"grade_id": opaque, "case": case.model_dump(mode="json"),
            "reference": {"expected": ref.expected.model_dump(mode="json"), "acceptance": ref.acceptance},
            "answer": result.answer.model_dump(mode="json")}
        files[f"{opaque}.json"] = _json({**content, "citations_supported": None,
            "rationale_correct": None, "reviewer_reason": None})
        mapping.append({"grade_id": opaque, "result_sha256": digest(result), "reference_sha256": digest(ref),
                        "content_sha256": digest(content)})
    files["README.md"] = b"# Blind semantic grading\n\nGrade citations and rationale against each frozen reference. Arms are hidden; wording may still reveal treatment. Keep unresolved judgements explicit.\n"
    # Publish the private mapping first; a failure cannot leave answers whose bindings were lost.
    publish_directory(private_mapping, {"mapping.json": _json(mapping)})
    publish_directory(output, files)


def import_grades(directory, mapping, reviewer):
    """Bind manual judgements back to exact hidden outputs without exposing arms."""
    if len({item["grade_id"] for item in mapping}) != len(mapping):
        raise ValueError("DUPLICATE_GRADE_MAPPING")
    grades = []
    for item in mapping:
        identity = item["grade_id"]
        if len(identity) != 26 or not identity.startswith("g_") or any(c not in "0123456789abcdef" for c in identity[2:]):
            raise ValueError("INVALID_GRADE_ID")
        page = json.loads((directory / f"{identity}.json").read_text())
        citations, rationale, reason = (page.pop(k) for k in ("citations_supported", "rationale_correct", "reviewer_reason"))
        if digest(page) != item["content_sha256"]:
            raise ValueError("BLIND_REVIEW_CONTENT_CHANGED")
        resolved = type(citations) is bool and type(rationale) is bool and bool(reason)
        grades.append(Grade(result_sha256=item["result_sha256"], reference_sha256=item["reference_sha256"],
            reviewer=reviewer, state="RESOLVED" if resolved else "UNRESOLVED",
            citations_supported=citations if type(citations) is bool else False,
            rationale_correct=rationale if type(rationale) is bool else False,
            reason=reason or "Awaiting explicit human semantic grade."))
    return grades

"""Immutable implementation/reference freezes for the offline pilot workflow."""

from datetime import datetime, timezone
from hashlib import sha256
import json

from ..immutable import publish_directory
from ..types import digest
from .contracts import Case, Reference
from .inputs import INSTRUCTIONS, TOOL, compile_inventory, reference_exists


def read_cases(path):
    return [Case.model_validate(item) for item in json.loads(path.read_text())]


def verify_implementation(root, freeze_path):
    freeze = json.loads(freeze_path.read_text())
    for entry in freeze["files"]:
        path = (root / entry["path"]).resolve()
        if not path.is_relative_to(root.resolve()) or sha256(path.read_bytes()).hexdigest() != entry["sha256"]:
            raise ValueError("IMPLEMENTATION_FREEZE_MISMATCH")
    if freeze["instructions_sha256"] != digest(INSTRUCTIONS) or freeze["tool_sha256"] != digest(TOOL):
        raise ValueError("PROMPT_SCHEMA_FREEZE_MISMATCH")
    return freeze


def freeze_references(design, cases, references, family_review, output):
    """Only explicit operator-supplied human records can reach this export.

    This local CLI trusts the operator's attribution of a human review, like the
    current assess-process workflow. It is not authenticated reviewer authority.
    """
    compile_inventory(design, cases)
    refs = {ref.case_id: ref for ref in references}
    if len(refs) != 24 or len(references) != 24 or set(refs) != {c.case_id for c in cases}:
        raise ValueError("REFERENCE_INVENTORY_INCOMPLETE")
    if set(family_review) != {"reviewer", "reviewed_at", "clusters", "reason"}:
        raise ValueError("INVALID_FAMILY_REVIEW")
    if not family_review["reviewer"] or not family_review["reason"]:
        raise ValueError("HUMAN_FAMILY_REVIEW_REQUIRED")
    timestamp = datetime.fromisoformat(family_review["reviewed_at"].replace("Z", "+00:00"))
    if timestamp.utcoffset() is None:
        raise ValueError("REVIEW_TIMESTAMP_REQUIRES_TIMEZONE")
    clusters = family_review["clusters"]
    if len(clusters) != 8 or len({c["family_id"] for c in clusters}) != 8:
        raise ValueError("INSUFFICIENT_FAMILY_DIVERSITY")
    covered = []
    for cluster in clusters:
        if set(cluster) != {"family_id", "case_ids", "separation_supported", "ancestry_reason"}:
            raise ValueError("INVALID_FAMILY_CLUSTER")
        if cluster["separation_supported"] is not True or not cluster["ancestry_reason"]:
            raise ValueError("INSUFFICIENT_FAMILY_DIVERSITY")
        members = cluster["case_ids"]
        if len(members) != 3 or any(x not in refs for x in members):
            raise ValueError("INVALID_FAMILY_MEMBERS")
        if {refs[x].stratum for x in members} != set(design.study["inventory"]["strata_per_family"]):
            raise ValueError("INVALID_FAMILY_STRATA")
        if any(refs[x].family_id != cluster["family_id"] for x in members):
            raise ValueError("FAMILY_REFERENCE_MISMATCH")
        covered.extend(members)
    if sorted(covered) != sorted(refs):
        raise ValueError("FAMILY_INVENTORY_MISMATCH")
    for case in cases:
        ref = refs[case.case_id]
        if ref.state != "VALID" or ref.packet_sha256 != digest(case):
            raise ValueError("REFERENCE_NOT_VALID_OR_WRONG_PACKET")
        if not all(reference_exists(case, r) for r in ref.expected.finding.references):
            raise ValueError("REFERENCE_CITATION_ABSENT")
    payload = {"version": "scope_pilot_human_references/1", "study_sha256": digest(design.study),
               "references": [ref.model_dump(mode="json") for ref in references], "family_review": family_review,
               "recorded_at": datetime.now(timezone.utc).isoformat(), "provider_execution_authorized": False}
    publish_directory(output, {"references.json": (json.dumps(payload, indent=2) + "\n").encode()})
    return digest(payload)

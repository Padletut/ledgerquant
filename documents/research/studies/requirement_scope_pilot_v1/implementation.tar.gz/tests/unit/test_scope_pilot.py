"""Development fixtures only; never import the pilot's candidate test inventory."""

from pathlib import Path

import pytest
from pydantic import ValidationError

from ledgerquant.research.types import digest
from ledgerquant.research.scope_pilot.contracts import Answer, Case, Grade, Reference, Result
from ledgerquant.research.scope_pilot.inputs import ARMS, load_design, prepare_requests, schedule
from ledgerquant.research.scope_pilot.scoring import score


ROOT = Path(__file__).resolve().parents[2]
DESIGN = ROOT / "configs/research/studies/requirement_scope_pilot_v1"


def case(number=0):
    return Case.model_validate({
        "case_id": f"c_{number:012x}", "provenance": "OPERATOR_AUTHORED_SYNTHETIC",
        "task": "Assess only requirement-scope consistency; no economic conclusion.",
        "context": {"current_scope": "Price-only diagnostic; no orders or economic claim.",
                    "record_notes": ["Development fixture; no measured market outcome."]},
        "draft": {"schema_version": "research_proposal/2", "title": "Development fixture",
                  "diagnostic": {"hours_utc": [12]}, "mechanism": "Test price continuation.",
                  "support": ["A testable conjecture, not evidence."],
                  "contrary_evidence": ["May fail on new data."],
                  "falsifier": "Fails the frozen predictive gate on eligible cases.",
                  "predicted_failure": "TEMPORAL_FAILURE", "admissibility_probability": 0.5,
                  "evidence_ids": ["synthetic-no-measurement"], "data_requirements": []}})


def answer(status="NOT_SUPPORTED", route="ASSESSABLE", reason="NONE"):
    return Answer.model_validate({"finding": {"code": "REQUIREMENT_SCOPE_CONFUSION", "status": status,
        "responsible_component": "research", "severity": "material", "references": ["draft.mechanism"],
        "applicability": "Current draft scope only.", "explanation": "Consistent current requirement."},
        "route": route, "escalation_reason": reason})


def inventory():
    cases, references, results, grades = [], [], [], []
    for i in range(24):
        packet = case(i)
        stratum = ("SUPPORTED_SCOPE_DEFECT", "VALID_NEAR_MISS", "MANDATORY_ESCALATION")[i % 3]
        a = answer(*(("SUPPORTED", "ASSESSABLE", "NONE") if i % 3 == 0 else
                    ("UNRESOLVED", "ESCALATE", "AMBIGUOUS_SCOPE") if i % 3 == 2 else
                    ("NOT_SUPPORTED", "ASSESSABLE", "NONE")))
        ref = Reference(case_id=packet.case_id, packet_sha256=digest(packet), family_id=f"family-{i // 3}",
            stratum=stratum, state="VALID", expected=a, acceptance="Explain the cited current requirement.",
            reviewer="development-test-reviewer", reviewed_at="2026-10-10T02:00:00Z",
            author_labels_seen=False, reason="Development reference, not a real human pilot review.")
        cases.append(packet)
        references.append(ref)
        for arm in ARMS:
            result = Result(case_id=packet.case_id, packet_sha256=digest(packet), arm=arm,
                            status="COMPLETED", answer=a, reason="Development response.")
            grade = Grade(result_sha256=digest(result), reference_sha256=digest(ref),
                reviewer="development-test-reviewer", state="RESOLVED", citations_supported=True,
                rationale_correct=True, reason="Development semantic grading only.")
            results.append(result)
            grades.append(grade)
    return cases, references, results, grades


def test_frozen_design_and_fresh_arm_inputs():
    design = load_design(ROOT, DESIGN)
    left, right = (prepare_requests(design, case(), arm) for arm in ARMS)
    import json
    a, b = [json.loads(x[1]["input"][0]["content"]) for x in (left, right)]
    assert b.pop("reviewed_method")
    assert a == b
    assert left[0] == right[0]
    assert left[1]["instructions"] == right[1]["instructions"]
    assert "reference" not in a and "family_id" not in a


def test_case_and_answer_fail_closed():
    payload = case().model_dump(mode="json")
    payload["reference_label"] = "SUPPORTED"
    with pytest.raises(ValidationError):
        Case.model_validate(payload)
    payload = case().model_dump(mode="json")
    payload["context"]["record_notes"] = ["x" * 4096]
    with pytest.raises(ValidationError):
        Case.model_validate(payload)
    with pytest.raises(ValidationError):
        answer(route="ESCALATE")
    with pytest.raises(ValidationError):
        answer(status="UNRESOLVED")


def test_schedule_is_paired_alternating_and_complete():
    rows = schedule([case(i) for i in range(24)])
    assert len(rows) == 48
    assert [r[1] for r in rows[:4]] == [ARMS[0], ARMS[1], ARMS[1], ARMS[0]]
    with pytest.raises(ValueError):
        schedule([case()] * 24)


def test_equal_perfect_arms_do_not_show_feedback_benefit():
    args = inventory()
    report = score(load_design(ROOT, DESIGN), *args, families_verified=True)
    assert report["decision"] == "NOT_PROMISING_UNDER_REGISTERED_RULE"
    assert report["track_a"]["delta"] == 0
    assert report["track_b"]["correct_in_class"] == 16
    assert report["automatic_permissions"] == []


def test_missing_outputs_and_invalid_reference_keep_full_denominator():
    cases, refs, results, grades = inventory()
    refs[0] = refs[0].model_copy(update={"state": "INVALID"})
    report = score(load_design(ROOT, DESIGN), cases, refs, results[1:], grades[1:], families_verified=True)
    assert report["decision"] == "INCONCLUSIVE"
    assert len(report["rows"]) == 48
    assert sum(row["semantic_eligible"] for row in report["rows"]) == 46
    assert sum(row["technical_status"] == "NOT_STARTED" for row in report["rows"]) == 1
    assert all(row["exact"] is None for row in report["rows"] if row["case_id"] == cases[0].case_id)


def test_semantic_grading_cannot_be_reused_for_changed_answer():
    cases, refs, results, grades = inventory()
    changed = results[1].answer.model_copy(update={"finding": results[1].answer.finding.model_copy(
        update={"explanation": "A changed answer needs fresh semantic grading."})})
    results[1] = results[1].model_copy(update={"answer": changed})
    report = score(load_design(ROOT, DESIGN), cases, refs, results, grades, families_verified=True)
    assert report["decision"] == "INCONCLUSIVE"
    assert report["track_b"]["false_accusations"] == 0  # first case is a defect
    assert report["complete_graded"] == 47


def test_bad_citation_is_not_rescued_by_human_grade():
    cases, refs, results, grades = inventory()
    bad = results[1].answer.model_copy(update={"finding": results[1].answer.finding.model_copy(
        update={"references": ("draft.nonexistent",)})})
    results[1] = results[1].model_copy(update={"answer": bad})
    grades[1] = grades[1].model_copy(update={"result_sha256": digest(results[1])})
    report = score(load_design(ROOT, DESIGN), cases, refs, results, grades, families_verified=True)
    assert report["track_b"]["invalid_or_unsupported_citation"] == 1


def test_unknown_or_duplicate_results_rejected():
    cases, refs, results, grades = inventory()
    with pytest.raises(ValueError):
        score(load_design(ROOT, DESIGN), cases, refs, results + results[:1], grades, families_verified=True)
    results[0] = results[0].model_copy(update={"packet_sha256": "f" * 64})
    with pytest.raises(ValueError):
        score(load_design(ROOT, DESIGN), cases, refs, results, grades, families_verified=True)


def test_preparation_and_review_do_not_dispatch_or_show_author_labels(tmp_path):
    from ledgerquant.research.scope_pilot.review import export_review
    from ledgerquant.research.scope_pilot.inputs import compile_inventory
    design = load_design(ROOT, DESIGN)
    cases = [case(i) for i in range(24)]
    compiled = compile_inventory(design, cases)
    assert len(compiled["rows"]) == 48
    assert compiled["provider_calls_made"] == 0
    assert compiled["execution_authorized"] is False
    assert compiled["reserved_micro_usd_upper_bound"] < 3_000_000
    export_review(design, cases, tmp_path / "review")
    text = (tmp_path / "review" / f"{cases[0].case_id}.md").read_text()
    assert "draft.mechanism" in text and "Current authorized scope" in text
    assert "expected" not in text and "stratum" not in text and "family_id" not in text
    import json
    form = json.loads((tmp_path / "review" / "review.form.json").read_text())
    assert all(item["status"] is None for item in form["cases"])
    with pytest.raises(ValueError):
        export_review(design, cases, tmp_path / "review")


def test_declared_family_ids_do_not_establish_diversity():
    report = score(load_design(ROOT, DESIGN), *inventory(), families_verified=False)
    assert report["decision"] == "INCONCLUSIVE"


def test_promising_gate_requires_measured_paired_improvement():
    cases, refs, results, grades = inventory()
    for index in (0, 6, 12, 18):
        result = results[index]
        result = result.model_copy(update={"answer": answer("NOT_SUPPORTED")})
        results[index] = result
        grades[index] = grades[index].model_copy(update={"result_sha256": digest(result)})
    report = score(load_design(ROOT, DESIGN), cases, refs, results, grades, families_verified=True)
    assert report["decision"] == "PROMISING_FOR_LARGER_STUDY"
    assert report["track_a"]["delta"] == pytest.approx(4 / 24)
    assert report["automatic_permissions"] == []
    stopped = score(load_design(ROOT, DESIGN), cases, refs, results, grades, families_verified=True, early_stop=True)
    assert stopped["decision"] == "INCONCLUSIVE"


def test_reference_freeze_requires_reviewed_diversity_and_never_authorizes_execution(tmp_path):
    import json
    from ledgerquant.research.scope_pilot.artifacts import freeze_references
    cases, refs, _, _ = inventory()
    families = {"reviewer": "development-reviewer", "reviewed_at": "2026-10-10T02:00:00Z",
        "reason": "Development fixture only.", "clusters": [
            {"family_id": f"family-{i}", "case_ids": [c.case_id for c in cases[i * 3:i * 3 + 3]],
             "separation_supported": True, "ancestry_reason": "Synthetic development fixture."} for i in range(8)]}
    design = load_design(ROOT, DESIGN)
    freeze_references(design, cases, refs, families, tmp_path / "references")
    assert json.loads((tmp_path / "references/references.json").read_text())["provider_execution_authorized"] is False
    families["clusters"][0]["separation_supported"] = False
    with pytest.raises(ValueError, match="INSUFFICIENT_FAMILY_DIVERSITY"):
        freeze_references(design, cases, refs, families, tmp_path / "rejected")


def test_blind_grading_excludes_arms_and_preserves_private_bindings(tmp_path):
    import json
    from ledgerquant.research.scope_pilot.review import blind_outputs, import_grades
    cases, refs, results, _ = inventory()
    blind_outputs(cases, refs, results, tmp_path / "blind", tmp_path / "private")
    mapping = json.loads((tmp_path / "private/mapping.json").read_text())
    assert len(mapping) == 48
    pages = list((tmp_path / "blind").glob("g_*.json"))
    assert len(pages) == 48
    for path in pages:
        raw = path.read_text()
        assert all(arm not in raw for arm in ARMS)
        assert "result_sha256" not in raw and "reference_sha256" not in raw
    grades = import_grades(tmp_path / "blind", mapping, "development-test-reviewer")
    assert all(g.state == "UNRESOLVED" for g in grades)
    first = json.loads(pages[0].read_text())
    first.update(citations_supported=True, rationale_correct=False, reviewer_reason="Citation valid; rationale not valid.")
    pages[0].write_text(json.dumps(first))
    grades = import_grades(tmp_path / "blind", mapping, "development-test-reviewer")
    assert sum(g.state == "RESOLVED" for g in grades) == 1
    first["answer"]["finding"]["explanation"] = "changed"
    pages[0].write_text(json.dumps(first))
    with pytest.raises(ValueError, match="BLIND_REVIEW_CONTENT_CHANGED"):
        import_grades(tmp_path / "blind", mapping, "development-test-reviewer")


def test_design_mutation_is_detected(tmp_path):
    import json
    import shutil
    directory = tmp_path / "configs/research/studies/requirement_scope_pilot_v1"
    shutil.copytree(DESIGN, directory)
    protocol = tmp_path / "documents/research/studies/requirement_scope_pilot_v1"
    protocol.mkdir(parents=True)
    shutil.copyfile(ROOT / "documents/research/studies/requirement_scope_pilot_v1/PROTOCOL.md", protocol / "PROTOCOL.md")
    load_design(tmp_path, directory)
    study = json.loads((directory / "study.json").read_text())
    study["pilot_decision"]["minimum_track_a_delta"] = 0
    (directory / "study.json").write_text(json.dumps(study))
    with pytest.raises(ValueError, match="FROZEN_DESIGN_CHANGED"):
        load_design(tmp_path, directory)
